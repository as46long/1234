package com.leyu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.leyu.entity.SongComment;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SongCommentMapper extends BaseMapper<SongComment> {
}
