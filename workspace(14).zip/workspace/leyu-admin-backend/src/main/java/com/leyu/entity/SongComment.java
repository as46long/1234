package com.leyu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_song_comment")
public class SongComment {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long songId;
    private Long userId;
    private String content;
    private Integer likes;
    private Integer status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
