import request from '@/utils/request'

export const uploadFile = (file) => {
  const formData = new FormData()
  formData.append('file', file)
  return request.post('/file/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export const uploadAudio = (file) => {
  const formData = new FormData()
  formData.append('file', file)
  return request.post('/file/uploadAudio', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export const uploadCover = (file) => {
  const formData = new FormData()
  formData.append('file', file)
  return request.post('/file/uploadCover', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}
