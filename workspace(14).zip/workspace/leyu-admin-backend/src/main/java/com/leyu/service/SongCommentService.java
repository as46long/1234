package com.leyu.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.dto.SongCommentDTO;
import com.leyu.vo.SongCommentVO;

import java.util.List;

public interface SongCommentService {
    Page<SongCommentVO> getSongComments(Long songId, int pageNum, int pageSize, Long userId);
    void postSongComment(Long userId, SongCommentDTO dto);
    void likeSongComment(Long commentId, Long userId);
    void banSongComment(Long commentId);
    void unbanSongComment(Long commentId);
    Page<SongCommentVO> getAdminSongComments(int pageNum, int pageSize, String category, Integer status);
    void deleteSongComment(Long commentId);
    Page<SongCommentVO> getMySongComments(Long userId, int pageNum, int pageSize);
}
