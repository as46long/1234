package com.leyu.service;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {
    String uploadFile(MultipartFile file);
    String uploadAvatar(MultipartFile file);
    String uploadAudio(MultipartFile file);
    String uploadCover(MultipartFile file);
}
