package com.leyu.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.dto.SongDTO;
import com.leyu.service.SongService;
import com.leyu.utils.JwtUtil;
import com.leyu.vo.Result;
import com.leyu.vo.SongVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/song")
@Tag(name = "歌曲管理")
public class SongController {

    @Autowired
    private SongService songService;

    @Autowired
    private JwtUtil jwtUtil;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @GetMapping("/list")
    @Operation(summary = "歌曲列表")
    public Result<Page<SongVO>> list(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {
        return Result.success(songService.getPage(pageNum, pageSize, keyword, category));
    }

    @GetMapping("/detail/{id}")
    @Operation(summary = "获取详情")
    public Result<SongVO> getById(@PathVariable Long id,
                                   @RequestHeader(value = "Authorization", required = false) String token) {
        Long userId = null;
        if (token != null && token.startsWith("Bearer ")) {
            userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        }
        return Result.success(songService.getVOById(id, userId));
    }

    @PostMapping("/add")
    @Operation(summary = "添加歌曲")
    public Result<Void> add(@RequestBody SongDTO dto) {
        songService.add(dto);
        return Result.success();
    }

    @PutMapping("/update")
    @Operation(summary = "更新歌曲")
    public Result<Void> update(@RequestBody SongDTO dto) {
        songService.update(dto);
        return Result.success();
    }

    @DeleteMapping("/delete/{id}")
    @Operation(summary = "删除歌曲")
    public Result<Void> delete(@PathVariable Long id) {
        songService.delete(id);
        return Result.success();
    }

    @GetMapping("/search")
    @Operation(summary = "搜索歌曲")
    public Result<List<SongVO>> search(@RequestParam String keyword,
                                        @RequestHeader(value = "Authorization", required = false) String token) {
        Long userId = null;
        if (token != null && token.startsWith("Bearer ")) {
            userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        }
        return Result.success(songService.search(keyword, userId));
    }

    @GetMapping("/recommend")
    @Operation(summary = "推荐歌曲")
    public Result<List<SongVO>> recommend(@RequestParam(required = false) Long userId,
                                          @RequestParam(defaultValue = "10") int num) {
        return Result.success(songService.getRecommend(userId, num));
    }

    @GetMapping("/hot")
    @Operation(summary = "热门歌曲")
    public Result<List<SongVO>> hot(@RequestParam(defaultValue = "10") int limit) {
        return Result.success(songService.getHot(limit));
    }

    @GetMapping("/category/{category}")
    @Operation(summary = "分类歌曲")
    public Result<List<SongVO>> byCategory(@PathVariable String category,
                                            @RequestHeader(value = "Authorization", required = false) String token) {
        Long userId = null;
        if (token != null && token.startsWith("Bearer ")) {
            userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        }
        return Result.success(songService.getByCategory(category, userId));
    }

    @PostMapping("/play/{id}")
    @Operation(summary = "记录播放")
    public Result<Void> play(@PathVariable Long id,
                             @RequestHeader(value = "Authorization", required = false) String token) {
        Long userId = null;
        if (token != null && token.startsWith("Bearer ")) {
            userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        }
        songService.incrementPlayCount(id, userId);
        return Result.success();
    }

    @GetMapping("/lyrics/{id}")
    @Operation(summary = "获取歌词")
    public Result<String> getLyrics(@PathVariable Long id) {
        return Result.success(songService.getLyrics(id));
    }

    @PutMapping("/lyrics/{id}")
    @Operation(summary = "更新歌词")
    public Result<Void> updateLyrics(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String lyrics = body.get("lyrics");
        songService.updateLyrics(id, lyrics);
        return Result.success();
    }

    @GetMapping("/lyrics/search")
    @Operation(summary = "搜索网络歌词")
    public Result<List<Map<String, Object>>> searchLyrics(@RequestParam String keyword) {
        List<Map<String, Object>> results = new ArrayList<>();
        
        try {
            String url = "https://music.163.com/api/search/get/web?s=" + keyword + "&type=1&limit=10";
            
            HttpHeaders headers = new HttpHeaders();
            headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            headers.set("Referer", "https://music.163.com");
            
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            
            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode songs = root.path("result").path("songs");
            
            if (songs.isArray()) {
                for (JsonNode song : songs) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("id", song.path("id").asText());
                    item.put("name", song.path("name").asText());
                    
                    StringBuilder artists = new StringBuilder();
                    JsonNode artistNode = song.path("artists");
                    if (artistNode.isArray()) {
                        for (int i = 0; i < artistNode.size(); i++) {
                            if (i > 0) artists.append(",");
                            artists.append(artistNode.get(i).path("name").asText());
                        }
                    }
                    item.put("artist", artists.toString());
                    item.put("album", song.path("album").path("name").asText());
                    
                    results.add(item);
                }
            }
        } catch (Exception e) {
            System.err.println("搜索歌词失败: " + e.getMessage());
        }
        
        return Result.success(results);
    }

    @GetMapping("/lyrics/fetch/{songId}")
    @Operation(summary = "获取网络歌词内容")
    public Result<String> fetchLyrics(@PathVariable String songId) {
        try {
            String url = "https://music.163.com/api/song/lyric?id=" + songId + "&lv=1";
            
            HttpHeaders headers = new HttpHeaders();
            headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            headers.set("Referer", "https://music.163.com");
            
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            
            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode lrcNode = root.path("lrc");
            
            if (!lrcNode.isMissingNode()) {
                JsonNode lyricText = lrcNode.path("lyric");
                if (!lyricText.isMissingNode() && lyricText.isTextual()) {
                    String lyrics = lyricText.asText();
                    return Result.success(lyrics);
                }
            }
        } catch (Exception e) {
            System.err.println("获取歌词失败: " + e.getMessage());
        }
        
        return Result.success("");
    }
}
