package com.leyu.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.service.CommentService;
import com.leyu.vo.CommentVO;
import com.leyu.vo.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/comment")
@Tag(name = "管理员-留言管理")
public class AdminCommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("/list")
    @Operation(summary = "获取留言列表")
    public Result<Page<CommentVO>> list(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Integer status) {
        return Result.success(commentService.getPage(pageNum, pageSize, status));
    }

    @PutMapping("/audit/{id}")
    @Operation(summary = "审核留言")
    public Result<Void> audit(@PathVariable Long id, @RequestParam Integer status) {
        commentService.audit(id, status);
        return Result.success();
    }

    @DeleteMapping("/delete/{id}")
    @Operation(summary = "删除留言")
    public Result<Void> delete(@PathVariable Long id) {
        commentService.delete(id);
        return Result.success();
    }
}
