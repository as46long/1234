package com.leyu.controller;

import com.leyu.service.FileService;
import com.leyu.vo.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/file")
@Tag(name = "文件管理")
public class FileController {

    @Autowired
    private FileService fileService;

    @PostMapping("/upload")
    @Operation(summary = "上传文件")
    public Result<String> upload(@RequestParam("file") MultipartFile file) {
        String url = fileService.uploadFile(file);
        return Result.success(url);
    }

    @PostMapping("/uploadAvatar")
    @Operation(summary = "上传头像")
    public Result<String> uploadAvatar(@RequestParam("file") MultipartFile file) {
        String url = fileService.uploadAvatar(file);
        return Result.success(url);
    }

    @PostMapping("/uploadAudio")
    @Operation(summary = "上传音频文件")
    public Result<String> uploadAudio(@RequestParam("file") MultipartFile file) {
        String url = fileService.uploadAudio(file);
        return Result.success(url);
    }

    @PostMapping("/uploadCover")
    @Operation(summary = "上传封面图片")
    public Result<String> uploadCover(@RequestParam("file") MultipartFile file) {
        String url = fileService.uploadCover(file);
        return Result.success(url);
    }
}
