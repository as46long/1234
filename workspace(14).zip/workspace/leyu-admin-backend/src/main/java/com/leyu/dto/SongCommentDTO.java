package com.leyu.dto;

import lombok.Data;

@Data
public class SongCommentDTO {
    private Long songId;
    private String content;
}
