# 用户指令记忆

本文件记录了用户的指令、偏好和教导，用于在未来的交互中提供参考。

## 格式

### 用户指令条目
用户指令条目应遵循以下格式：

[用户指令摘要]
- Date: [YYYY-MM-DD]
- Context: [提及的场景或时间]
- Instructions:
  - [用户教导或指示的内容，逐行描述]

### 项目知识条目
Agent 在任务执行过程中发现的条目应遵循以下格式：

[项目知识摘要]
- Date: [YYYY-MM-DD]
- Context: Agent 在执行 [具体任务描述] 时发现
- Category: [代码结构|代码模式|代码生成|构建方法|测试方法|依赖关系|环境配置]
- Instructions:
  - [具体的知识点，逐行描述]

## 去重策略
- 添加新条目前，检查是否存在相似或相同的指令
- 若发现重复，跳过新条目或与已有条目合并
- 合并时，更新上下文或日期信息
- 这有助于避免冗余条目，保持记忆文件整洁

## 条目

[项目技术栈与架构]
- Date: 2026-04-27
- Context: Agent 在分析项目结构和实现微信登录与歌曲评论功能时发现
- Category: 代码结构|依赖关系|环境配置
- Instructions:
  - 后端使用 Spring Boot 3.2 + MyBatis-Plus + MySQL (Java 21)
  - 管理后台使用 Vue.js 3 + Element Plus + Vite
  - 小程序使用微信原生小程序开发
  - 项目采用前后端分离架构
  - 使用 JWT 进行身份认证
  - 数据库表命名规则为 t_前缀
  - 实体类使用 Lombok 注解简化代码
  - Controller 层使用 Swagger/Knife4j 生成 API 文档

[项目数据库设计]
- Date: 2026-04-27
- Context: Agent 在设计歌曲评论表和扩展留言表时发现
- Category: 代码结构|数据库设计
- Instructions:
  - 歌曲评论表 t_song_comment 与原留言表 t_comment 结构类似
  - 歌曲评论表增加 song_id 字段关联歌曲
  - 歌曲评论状态设计为 0-已封禁 1-正常
  - 原留言表增加 comment_type 字段区分留言类型 (1-乐语留言 2-歌曲留言)
  - 所有表都有统一的 create_time 和 update_time 字段
  - 主键使用 BIGINT 自增
  - 外键字段使用 BIGINT 类型

[项目API设计规范]
- Date: 2026-04-27
- Context: Agent 在实现歌曲评论和管理后台接口时发现
- Category: 代码模式|API设计
- Instructions:
  - 用户端接口使用 /api/ 前缀
  - 管理员端接口使用 /api/admin/ 前缀
  - 使用 Result 统一包装响应结果 {code, message, data}
  - 分页使用 MyBatis-Plus 的 Page 对象
  - DTO 用于接收前端数据，VO 用于返回前端数据
  - Controller 方法参数使用 @RequestHeader 获取 token
  - 删除操作使用 DELETE 方法
  - 更新操作使用 PUT 方法

[小程序开发规范]
- Date: 2026-04-27
- Context: Agent 在实现播放器评论功能和登录功能时发现
- Category: 代码模式|代码结构
- Instructions:
  - 使用 app.globalData 存储全局状态 (token, userInfo, audioManager)
  - 使用 wx.getStorageSync 和 wx.setStorageSync 持久化存储
  - 网络请求封装在 utils/api.js 中，自动添加 token
  - 页面使用 Page() 构造器创建
  - 组件使用 Component() 构造器创建
  - 使用 setData 更新页面数据，触发视图更新
  - 弹窗使用 catchtouchmove="true" 防止滚动穿透
  - 样式文件使用 .wxss 后缀
  - 模板文件使用 .wxml 后缀
  - 逻辑文件使用 .js 后缀
  - 配置文件使用 .json 后缀

[管理后台开发规范]
- Date: 2026-04-27
- Context: Agent 在创建歌曲留言管理和乐语留言管理页面时发现
- Category: 代码模式|代码结构
- Instructions:
  - 使用 Vue 3 Composition API (setup语法糖)
  - 使用 Element Plus UI 组件库
  - 使用 el-card 包裹页面内容
  - 使用 el-table 展示列表数据
  - 使用 el-pagination 实现分页
  - 使用 el-select 实现下拉筛选
  - 使用 ElMessage 和 ElMessageBox 实现提示和确认框
  - 使用 ref 定义响应式数据
  - 使用 onMounted 生命周期钩子
  - API 请求封装在 @/api 目录下
  - 使用 request 工具统一处理 HTTP 请求
  - 路由配置在 @/router/index.js
  - 布局组件使用 el-container, el-header, el-aside, el-main
