package com.leyu.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.dto.LoginDTO;
import com.leyu.dto.RegisterDTO;
import com.leyu.service.UserService;
import com.leyu.utils.JwtUtil;
import com.leyu.vo.Result;
import com.leyu.vo.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
@Tag(name = "用户管理")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    @Operation(summary = "用户登录")
    public Result<Map<String, Object>> login(@Valid @RequestBody LoginDTO dto) {
        UserVO user = userService.login(dto);
        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), "USER");
        Map<String, Object> result = new HashMap<>();
        result.put("user", user);
        result.put("token", token);
        return Result.success(result);
    }

    @PostMapping("/wxLogin")
    @Operation(summary = "微信登录")
    public Result<Map<String, Object>> wxLogin(@RequestBody Map<String, String> request) {
        try {
            String code = request.get("code");
            if (code == null || code.isEmpty()) {
                return Result.error(400, "缺少code参数");
            }

            UserVO user = userService.wxLogin(code);
            String token = jwtUtil.generateToken(user.getId(), user.getUsername(), "USER");
            Map<String, Object> result = new HashMap<>();
            result.put("user", user);
            result.put("token", token);
            return Result.success(result);
        } catch (Exception e) {
            System.out.println("微信登录异常: " + e.getMessage());
            e.printStackTrace();
            return Result.error(500, "微信登录失败：" + e.getMessage());
        }
    }

    @PostMapping("/register")
    @Operation(summary = "用户注册")
    public Result<Void> register(@Valid @RequestBody RegisterDTO dto) {
        userService.register(dto);
        return Result.success();
    }

    @GetMapping("/info")
    @Operation(summary = "获取当前用户信息")
    public Result<UserVO> info(@RequestHeader("Authorization") String token) {
        Long userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        return Result.success(userService.getById(userId));
    }

    @PutMapping("/update")
    @Operation(summary = "更新用户信息")
    public Result<Void> update(@RequestHeader("Authorization") String token, @RequestBody UserVO vo) {
        Long userId = jwtUtil.getUserId(token.replace("Bearer ", ""));
        userService.update(userId, vo);
        return Result.success();
    }
}
