const api = require('../../utils/api')
const audioManager = require('../../utils/audioManager')
const app = getApp()

Page({
  data: {
    banners: [],
    recommendSongs: [],
    categories: ['流行', '摇滚', '古典', '民谣', '电子'],
    categorySongs: {}, // 存储各分类的歌曲
    loading: true,
    showMusicBar: false
  },

 onLoad() {
   this.loadData()
   this.checkCurrentSong()
 },

 onShow() {
   this.checkCurrentSong()
 },
  onUnload() {
    // 移除事件监听
    if (this.songChangeHandler) {
      audioManager.off('songChange', this.songChangeHandler)
    }
  },

  onPullDownRefresh() {
    this.loadData().then(() => wx.stopPullDownRefresh())
  },

  async loadData() {
    try {
      const userId = app.globalData.userInfo?.id || 0
      const [recommendRes, ...categoryResults] = await Promise.all([
        api.getRecommend(userId),
        ...this.data.categories.map(cat => api.getSongsByCategory(cat).catch(() => ({ data: [] })))
      ])
      
      const categorySongs = {}
      this.data.categories.forEach((cat, index) => {
        categorySongs[cat] = categoryResults[index]?.data || []
      })
      
      this.setData({
        recommendSongs: recommendRes.data || [],
        categorySongs,
        loading: false
      })
    } catch (e) {
      this.setData({ loading: false })
    }
  },

checkCurrentSong() {
  const currentSong = audioManager.getCurrentSong()
  console.log('=== 首页检查当前歌曲 ===', currentSong)
  this.setData({
    showMusicBar: !!currentSong
  })
  console.log('=== showMusicBar 状态 ===', this.data.showMusicBar)
   // 监听歌曲变化事件
   if (!this.songChangeHandler) {
     this.songChangeHandler = (song) => {
       console.log('=== 首页收到歌曲变化事件 ===', song)
       this.setData({
         showMusicBar: !!song
       })
     }
     audioManager.on('songChange', this.songChangeHandler)
   }
},

  onSearchTap() {
    wx.navigateTo({ url: '/pages/search/search' })
  },

  onCategoryTap(e) {
    const category = e.currentTarget.dataset.category
    wx.navigateTo({ url: `/pages/search/search?category=${category}` })
  },

  onSongTap(e) {
    const song = e.currentTarget.dataset.song
    wx.navigateTo({ url: `/pages/player/player?id=${song.id}` })
  },

  onPlayAllTap() {
    if (this.data.recommendSongs.length > 0) {
      const songs = this.data.recommendSongs
      // 保存播放列表到全局数据
      app.globalData.playAllList = songs
      wx.navigateTo({ url: `/pages/player/player?id=${songs[0].id}&playAll=true` })
    }
  }
})
