package com.leyu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.dto.LoginDTO;
import com.leyu.dto.RegisterDTO;
import com.leyu.entity.User;
import com.leyu.mapper.UserMapper;
import com.leyu.service.UserService;
import com.leyu.utils.JwtUtil;
import com.leyu.utils.PasswordEncoder;
import com.leyu.utils.WechatUtil;
import com.leyu.vo.UserVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private WechatUtil wechatUtil;

    @Value("${wechat.appid}")
    private String wechatAppid;

    @Value("${wechat.secret}")
    private String wechatSecret;

    @Override
    public UserVO login(LoginDTO dto) {
        User user = getByUsername(dto.getUsername());
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            throw new RuntimeException("密码错误");
        }
        if (user.getStatus() == 0) {
            throw new RuntimeException("账号已被禁用");
        }
        return convertToVO(user);
    }

    @Override
    public UserVO wxLogin(String code) {
        try {
            // 开发测试阶段：如果code不是真实的微信code，直接使用code作为openid
            String openid = code;

            // 尝试调用微信API获取openid（如果配置了真实的AppID和AppSecret）
            if (!"your_appid_here".equals(wechatAppid) && !"your_secret_here".equals(wechatSecret)) {
                try {
                    WechatUtil.WechatLoginResult result = wechatUtil.code2Session(wechatAppid, wechatSecret, code);
                    if (result.isSuccess()) {
                        openid = result.getOpenid();
                    } else {
                        // 微信API调用失败，降级使用code作为openid
                        System.out.println("微信API调用失败，使用code作为openid: " + result.getErrmsg());
                    }
                } catch (Exception e) {
                    // 微信API调用异常，降级使用code作为openid
                    System.out.println("微信API调用异常，使用code作为openid: " + e.getMessage());
                }
            }

            User user = userMapper.selectOne(new LambdaQueryWrapper<User>().eq(User::getWxOpenid, openid));
            if (user == null) {
                user = new User();
                user.setWxOpenid(openid);
                user.setUsername("wx_" + System.currentTimeMillis());
                user.setPassword(passwordEncoder.encode("123456"));
                user.setNickname("微信用户");
                user.setIsVip(0);
                user.setStatus(1);
                userMapper.insert(user);
            } else if (user.getStatus() == 0) {
                throw new RuntimeException("账号已被禁用");
            }
            return convertToVO(user);
        } catch (Exception e) {
            throw new RuntimeException("微信登录失败：" + e.getMessage());
        }
    }

    @Override
    public UserVO register(RegisterDTO dto) {
        if (getByUsername(dto.getUsername()) != null) {
            throw new RuntimeException("用户名已存在");
        }
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setNickname(StringUtils.hasText(dto.getNickname()) ? dto.getNickname() : dto.getUsername());
        user.setPhone(dto.getPhone());
        user.setIsVip(0);
        user.setStatus(1);
        userMapper.insert(user);
        return convertToVO(user);
    }

    @Override
    public User getByUsername(String username) {
        return userMapper.selectOne(new LambdaQueryWrapper<User>().eq(User::getUsername, username));
    }

    @Override
    public User getEntityById(Long id) {
        return userMapper.selectById(id);
    }

    @Override
    public UserVO getById(Long id) {
        User user = userMapper.selectById(id);
        return user != null ? convertToVO(user) : null;
    }

    @Override
    public Page<UserVO> getPage(int pageNum, int pageSize, String keyword) {
        Page<User> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            wrapper.like(User::getUsername, keyword).or().like(User::getPhone, keyword);
        }
        wrapper.orderByDesc(User::getCreateTime);
        Page<User> userPage = userMapper.selectPage(page, wrapper);
        Page<UserVO> voPage = new Page<>(pageNum, pageSize, userPage.getTotal());
        voPage.setRecords(userPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList()));
        return voPage;
    }

    @Override
    public void update(Long id, UserVO vo) {
        User user = userMapper.selectById(id);
        if (user != null) {
            if (StringUtils.hasText(vo.getNickname())) {
                user.setNickname(vo.getNickname());
            }
            if (StringUtils.hasText(vo.getAvatar())) {
                user.setAvatar(vo.getAvatar());
            }
            if (StringUtils.hasText(vo.getPhone())) {
                user.setPhone(vo.getPhone());
            }
            if (StringUtils.hasText(vo.getEmail())) {
                user.setEmail(vo.getEmail());
            }
            userMapper.updateById(user);
        }
    }

    @Override
    public void updateStatus(Long id, Integer status) {
        User user = new User();
        user.setId(id);
        user.setStatus(status);
        userMapper.updateById(user);
    }

    @Override
    public void delete(Long id) {
        userMapper.deleteById(id);
    }

    private UserVO convertToVO(User user) {
        UserVO vo = new UserVO();
        BeanUtils.copyProperties(user, vo);
        return vo;
    }
}
