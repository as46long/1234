package com.leyu.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.leyu.service.OrderService;
import com.leyu.vo.OrderVO;
import com.leyu.vo.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/order")
@Tag(name = "管理员-订单管理")
public class AdminOrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/list")
    @Operation(summary = "获取订单列表")
    public Result<Page<OrderVO>> list(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Integer payStatus,
            @RequestParam(required = false) String packageType) {
        return Result.success(orderService.getPage(pageNum, pageSize, payStatus, packageType));
    }

    @GetMapping("/detail/{orderNo}")
    @Operation(summary = "获取订单详情")
    public Result<OrderVO> detail(@PathVariable String orderNo) {
        return Result.success(orderService.getByOrderNo(orderNo));
    }
}
