const api = require('../../utils/api')
const app = getApp()

Page({
  data: {
    username: '',
    password: '',
    isRegister: false,
    nickname: ''
  },

  onUsernameInput(e) {
    this.setData({ username: e.detail.value })
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value })
  },

  onNicknameInput(e) {
    this.setData({ nickname: e.detail.value })
  },

  toggleMode() {
    this.setData({ isRegister: !this.data.isRegister })
  },

  async handleWxLogin() {
    try {
      wx.showLoading({ title: '登录中...' })

      // 调用微信登录获取 code
      wx.login({
        success: async (res) => {
          if (!res.code) {
            wx.hideLoading()
            wx.showToast({ title: '获取微信登录码失败', icon: 'none' })
            return
          }

          console.log('获取到的微信登录码:', res.code)

          try {
            // 调用后端接口进行登录
            const apiResult = await api.wxLogin({ code: res.code })
            console.log('后端登录结果:', apiResult)

            // 保存登录信息
            wx.setStorageSync('token', apiResult.data.token)
            app.globalData.token = apiResult.data.token
            app.globalData.userInfo = apiResult.data.user

            wx.hideLoading()
            wx.showToast({ title: '登录成功', icon: 'success' })

            // 延迟跳转，让用户看到成功提示
            setTimeout(() => {
              wx.navigateBack()
            }, 1500)

          } catch (apiError) {
            wx.hideLoading()
            console.error('后端登录失败:', apiError)

            // 显示友好的错误提示
            let errorMsg = '登录失败，请重试'
            if (apiError.message) {
              errorMsg = apiError.message
            } else if (apiError.data && apiError.data.message) {
              errorMsg = apiError.data.message
            }

            wx.showToast({
              title: errorMsg,
              icon: 'none',
              duration: 2000
            })
          }
        },
        fail: (err) => {
          wx.hideLoading()
          console.error('微信登录失败:', err)
          wx.showToast({
            title: '微信登录失败',
            icon: 'none',
            duration: 2000
          })
        }
      })

    } catch (e) {
      wx.hideLoading()
      console.error('登录异常:', e)
      wx.showToast({
        title: '登录异常，请重试',
        icon: 'none',
        duration: 2000
      })
    }
  },

  async handleSubmit() {
    const { username, password, nickname, isRegister } = this.data
    if (!username || !password) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' })
      return
    }

    try {
      let res
      if (isRegister) {
        res = await api.register({ username, password, nickname })
        // 注册成功后直接跳转到登录
        wx.showToast({ title: '注册成功，请登录', icon: 'success' })
        setTimeout(() => {
          this.setData({ isRegister: false })
        }, 1500)
      } else {
        res = await api.login({ username, password })
        wx.setStorageSync('token', res.data.token)
        app.globalData.token = res.data.token
        app.globalData.userInfo = res.data.user
        
        wx.showToast({ title: '登录成功', icon: 'success' })
        setTimeout(() => wx.navigateBack(), 1500)
      }
    } catch (e) {
      console.error(e)
    }
  }
})
