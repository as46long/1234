package com.leyu.dto;

import lombok.Data;

@Data
public class FavoriteDTO {
    private Long songId;
}
