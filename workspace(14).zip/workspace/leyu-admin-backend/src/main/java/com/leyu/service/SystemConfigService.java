package com.leyu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.leyu.entity.SystemConfig;

public interface SystemConfigService extends IService<SystemConfig> {

    String getConfigValue(String key);

    void setConfigValue(String key, String value);
}
